# Tikis — Bundle de synchronisation

**Commit source** : `9adae84` (squash des 8 refontes + fix typo)
**Date** : 2026-08-29
**14 fichiers** à copier dans le repo de l'agent récepteur.

## Fichiers inclus

```
app/(tabs)/_layout.tsx              (modifié)
app/(tabs)/addresses.tsx            (modifié — fix typo + refonte)
app/(tabs)/index.tsx                (modifié — dispatcher)
app/(tabs)/index.web.tsx            (nouveau)
app/(tabs)/index.native.tsx         (nouveau)
app/(tabs)/live.tsx                 (nouveau — dispatcher)
app/(tabs)/live.web.tsx             (nouveau)
app/(tabs)/live.native.tsx          (nouveau)
app/(tabs)/profile.tsx              (modifié)
app/(tabs)/wallet.tsx               (modifié)
app/create-delivery.tsx             (modifié)
app/delivery/[id].tsx               (modifié)
app/notifications.tsx               (modifié)
components/tikis/candidates-sheet.tsx (nouveau)
```

## Comment appliquer

1. **Sauvegarder** ta version actuelle des 14 fichiers (par sécurité)
2. **Copier** les 14 fichiers depuis ce bundle dans ton repo, aux chemins indiqués ci-dessus (respecter la structure)
3. **Vérifier** que ton remote pointe bien sur `https://github.com/kaso-tech/tikis.git`
4. **Lancer un clear cache Expo** :
   ```bash
   rm -rf .expo node_modules/.cache
   npx expo start -c
   ```
5. **Committer** localement :
   ```bash
   git add -A
   git commit -m "Sync refontes Tikis (8 pages) depuis 9adae84"
   git push origin main
   ```

## Vérification

Une fois appliqué, tu devrais voir :
- 6 nouveaux fichiers (index.web.tsx, index.native.tsx, live.tsx, live.web.tsx, live.native.tsx, candidates-sheet.tsx)
- 8 fichiers modifiés (addresses, create-delivery, delivery/[id], index, _layout, notifications, profile, wallet)

## Refontes incluses (résumé)

1. **Onglet Suivi** : Google Maps style + sheet draggable + 3 chips filtres
2. **Accueil** : mission control + carte plein écran + card urgente
3. **Détail livraison** : hero map + timeline + sheet candidats
4. **Création** : page unique + progress + footer persistant
5. **Profil** : hero centré + sections claires + modal édition
6. **Adresses** : filtres typés + icônes par catégorie
7. **Notifications** : liste compacte + états lu/non lu par fond
8. **Wallet** : gradient sombre + trend pill + journal typé

Tokens utilisés : `#007B8B` / `#EEEDF3` / `#FFFFFF` / `#111111` / `#666666` / `#747474` / `#167A55` / `#9A6200` / `#B4232D`
