import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { KeyboardAvoidingView, Modal, Platform, Pressable, ScrollView, StyleSheet, Text, TextInput, View } from "react-native";
import { SafeAreaView } from "react-native-safe-area-context";
import { TikisButton } from "@/components/tikis/ui";
import { offeredPriceError, parseOfferedPrice, sanitizeOfferedPriceInput } from "@/lib/delivery-price";
import { useTikisStore } from "@/lib/tikis-store";
import { trpc } from "@/lib/trpc";
import { availableWalletBalance, formatMoney, formatRelativeDate, type WalletOperation } from "@/shared/tikis-domain";

type Tone = "primary" | "success" | "warning" | "error" | "neutral";

const operationMeta: Record<WalletOperation, { label: string; icon: React.ComponentProps<typeof MaterialIcons>["name"]; tone: Tone }> = {
  block: { label: "Commission bloquée", icon: "lock-clock", tone: "warning" },
  unblock: { label: "Commission débloquée", icon: "lock-open", tone: "primary" },
  debit: { label: "Commission prélevée", icon: "north-east", tone: "error" },
  compensation: { label: "Compensation", icon: "sync-alt", tone: "primary" },
  credit: { label: "Crédit", icon: "south-west", tone: "success" },
  refund: { label: "Remboursement", icon: "replay", tone: "success" },
  deposit_request: { label: "Dépôt en attente", icon: "add-card", tone: "warning" },
  withdrawal_request: { label: "Retrait en attente", icon: "account-balance-wallet", tone: "warning" },
};

const TONE_COLOR: Record<Tone, string> = {
  primary: "#007B8B",
  success: "#167A55",
  warning: "#9A6200",
  error: "#B4232D",
  neutral: "#666666",
};

export default function WalletScreen() {
  const { role, profile } = useTikisStore();
  const walletQuery = trpc.wallet.snapshot.useQuery(undefined, { enabled: Boolean(profile?.phone), refetchInterval: 12_000 });
  const wallet = walletQuery.data?.wallet ?? { total: 0, blocked: 0 };
  const journal = walletQuery.data?.journal ?? [];
  const initiateMutation = trpc.wallet.initiateLigdiSimulation.useMutation();
  const settleMutation = trpc.wallet.settleLigdiSimulation.useMutation({ onSuccess: () => void walletQuery.refetch() });
  const [requestType, setRequestType] = useState<"deposit" | "withdrawal" | null>(null);
  const [amountInput, setAmountInput] = useState("");
  const [requestError, setRequestError] = useState("");
  const [payment, setPayment] = useState<{ id: string; type: "deposit" | "withdrawal"; amount: number; providerReference: string } | null>(null);
  const requestLoading = initiateMutation.isPending || settleMutation.isPending;
  const isDriver = role === "driver";
  const available = availableWalletBalance(wallet);
  const completed = journal.filter((entry) => entry.operation === "credit" || entry.operation === "debit" || entry.operation === "refund");
  const todaysCount = journal.filter((entry) => {
    const d = new Date(entry.createdAt);
    const now = new Date();
    return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate();
  }).length;
  const todaysEarnings = journal
    .filter((entry) => {
      const d = new Date(entry.createdAt);
      const now = new Date();
      return d.getFullYear() === now.getFullYear() && d.getMonth() === now.getMonth() && d.getDate() === now.getDate() && entry.operation === "credit";
    })
    .reduce((sum, entry) => sum + entry.amount, 0);

  function openRequest(type: "deposit" | "withdrawal") { setRequestError(""); setAmountInput(""); setPayment(null); setRequestType(type); }
  async function confirmRequest() {
    const amount = parseOfferedPrice(amountInput);
    const error = offeredPriceError(amountInput) ?? (!amount || amount < 100 ? "Saisissez au moins 100 FCFA." : "");
    if (error || !amount) { setRequestError(error || "Montant invalide."); return; }
    try {
      const result = await initiateMutation.mutateAsync({ type: requestType!, amount, idempotencyKey: `ligdi-${Date.now()}-${Math.random().toString(36).slice(2, 14)}` });
      setPayment(result);
    } catch (cause) { setRequestError(cause instanceof Error ? cause.message : "La demande Ligdi Cash n’a pas pu être initialisée."); }
  }
  async function settlePayment(outcome: "succeeded" | "failed") {
    if (!payment) return;
    try {
      await settleMutation.mutateAsync({ paymentId: payment.id, outcome });
      setPayment(null); setRequestType(null); setAmountInput("");
    } catch (cause) { setRequestError(cause instanceof Error ? cause.message : "La confirmation Ligdi Cash a échoué."); }
  }

  return (
    <SafeAreaView style={styles.safe} edges={["top"]}>
      <View style={styles.topBar}>
        <Pressable onPress={() => null} style={styles.iconBtn} accessibilityLabel="Ouvrir le menu">
          <MaterialIcons name="menu" size={20} color="#111111" />
        </Pressable>
        <Text style={styles.topTitle}>Wallet</Text>
        <Pressable style={styles.iconBtn} accessibilityLabel="Plus d'options">
          <MaterialIcons name="more-horiz" size={20} color="#111111" />
        </Pressable>
      </View>

      <ScrollView contentContainerStyle={styles.scroll} showsVerticalScrollIndicator={false}>
        <View style={[styles.balanceCard, isDriver ? styles.balanceCardDriver : styles.balanceCardSender]}>
          <Text style={[styles.balanceEyebrow, isDriver && styles.balanceEyebrowLight]}>
            {isDriver ? "SOLDE DISPONIBLE" : "VOTRE WALLET EXPÉDITEUR"}
          </Text>
          <View style={styles.balanceValueRow}>
            <Text style={styles.balanceValue}>{formatMoney(available)}</Text>
            {isDriver ? (
              <View style={styles.trendPill}>
                <MaterialIcons name="trending-up" size={11} color="#48B889" />
                <Text style={styles.trendText}>+12%</Text>
              </View>
            ) : (
              <View style={styles.trendPillLight}>
                <MaterialIcons name="inventory-2" size={11} color="#FFFFFF" />
                <Text style={styles.trendTextLight}>{todaysCount || 0} course{todaysCount > 1 ? "s" : ""}</Text>
              </View>
            )}
          </View>
          <View style={[styles.balanceDivider, isDriver && styles.balanceDividerLight]} />
          <View style={styles.balanceRows}>
            {isDriver ? (
              <>
                <View style={styles.balanceCol}>
                  <Text style={[styles.balanceLabel, isDriver && styles.balanceLabelLight]}>Solde total</Text>
                  <Text style={styles.balanceSub}>{formatMoney(wallet.total)}</Text>
                </View>
                <View style={styles.balanceCol}>
                  <Text style={[styles.balanceLabel, isDriver && styles.balanceLabelLight]}>Bloquée</Text>
                  <Text style={styles.balanceSub}>{formatMoney(wallet.blocked)}</Text>
                </View>
                <View style={styles.balanceCol}>
                  <Text style={[styles.balanceLabel, isDriver && styles.balanceLabelLight]}>En attente</Text>
                  <Text style={[styles.balanceSub, styles.balanceSubPending]}>0 F</Text>
                </View>
              </>
            ) : (
              <>
                <View style={styles.balanceCol}>
                  <Text style={[styles.balanceLabel, isDriver && styles.balanceLabelLight]}>Engagées</Text>
                  <Text style={styles.balanceSub}>{journal.filter((e) => e.operation === "block").length} courses</Text>
                </View>
                <View style={styles.balanceCol}>
                  <Text style={[styles.balanceLabel, isDriver && styles.balanceLabelLight]}>Ce mois</Text>
                  <Text style={styles.balanceSub}>8 450 F</Text>
                </View>
              </>
            )}
          </View>
        </View>

        <View style={styles.actionsRow}>
          <Pressable onPress={() => openRequest("deposit")} style={({ pressed }) => [styles.actionCard, pressed && styles.pressed]}>
            <View style={styles.actionIcon}><MaterialIcons name="add-card" size={15} color="#007B8B" /></View>
            <View style={styles.actionText}>
              <Text style={styles.actionLabel}>Dépôt</Text>
              <Text style={styles.actionSub}>Ligdi Cash</Text>
            </View>
          </Pressable>
          <Pressable onPress={() => openRequest("withdrawal")} style={({ pressed }) => [styles.actionCard, pressed && styles.pressed]}>
            <View style={[styles.actionIcon, styles.actionIconAlt]}><MaterialIcons name="account-balance-wallet" size={15} color="#007B8B" /></View>
            <View style={styles.actionText}>
              <Text style={styles.actionLabel}>Retrait</Text>
              <Text style={styles.actionSub}>Mobile Money</Text>
            </View>
          </Pressable>
        </View>

        {isDriver ? (
          <View style={styles.quickStats}>
            <QuickStat icon="local-shipping" value={String(todaysCount)} label="Aujourd'hui" tone="primary" />
            <QuickStat icon="savings" value={formatMoney(todaysEarnings)} label="Gains" tone="success" />
            <QuickStat icon="two-wheeler" value="47" label="Courses" tone="amber" />
          </View>
        ) : (
          <View style={styles.senderInfo}>
            <View style={styles.senderInfoIcon}><MaterialIcons name="handshake" size={16} color="#FFFFFF" /></View>
            <Text style={styles.senderInfoText}>
              <Text style={styles.senderInfoTextBold}>Paiement direct au livreur. </Text>
              Le règlement de la course se fait à la remise. Les mouvements Tikis sont réservés aux règles de mise en relation.
            </Text>
          </View>
        )}

        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>{isDriver ? "Journal financier" : "Activité financière"}</Text>
          <Text style={styles.sectionAction}>Voir tout</Text>
        </View>

        {walletQuery.isLoading ? (
          <View style={styles.listCard}><Text style={styles.emptyText}>Chargement sécurisé de vos opérations…</Text></View>
        ) : walletQuery.error ? (
          <View style={styles.listCard}><Text style={styles.emptyText}>Le journal financier est momentanément indisponible.</Text></View>
        ) : completed.length === 0 ? (
          <View style={styles.empty}>
            <View style={styles.emptyIcon}><MaterialIcons name="savings" size={26} color="#747474" /></View>
            <Text style={styles.emptyTitle}>Aucun mouvement enregistré</Text>
            <Text style={styles.emptySub}>Vos premières opérations apparaîtront ici après votre premier dépôt ou votre première course.</Text>
          </View>
        ) : (
          <View style={styles.listCard}>
            {completed.slice(0, 6).map((entry, idx) => {
              const meta = operationMeta[entry.operation];
              const isLast = idx === Math.min(completed.length, 6) - 1;
              const isCredit = entry.operation === "credit" || entry.operation === "refund" || entry.operation === "unblock" || entry.operation === "compensation";
              const isPending = entry.operation === "block" || entry.operation === "deposit_request" || entry.operation === "withdrawal_request";
              const amountColor = isCredit ? styles.amountCredit : isPending ? styles.amountPending : styles.amountDebit;
              const amountPrefix = isCredit ? "+" : isPending ? "" : "-";
              return (
                <View key={entry.id} style={[styles.txRow, !isLast && styles.txRowDivider]}>
                  <View style={[styles.txIcon, iconBgForTone(meta.tone)]}>
                    <MaterialIcons name={meta.icon} size={16} color={TONE_COLOR[meta.tone]} />
                  </View>
                  <View style={styles.txBody}>
                    <View style={styles.txLine1}>
                      <Text style={styles.txLabel} numberOfLines={1}>{meta.label}</Text>
                      <Text style={styles.txTime}>{formatRelativeDate(entry.createdAt)}</Text>
                    </View>
                    <Text style={styles.txReason} numberOfLines={1}>{entry.reason}</Text>
                  </View>
                  <Text style={[styles.txAmount, amountColor]}>{amountPrefix}{formatMoney(entry.amount)}</Text>
                </View>
              );
            })}
          </View>
        )}
      </ScrollView>

      <Modal visible={requestType !== null} transparent animationType="slide" onRequestClose={() => !requestLoading && setRequestType(null)}>
        <KeyboardAvoidingView behavior={Platform.OS === "ios" ? "padding" : undefined} style={styles.modalOverlay}>
          <Pressable style={StyleSheet.absoluteFill} onPress={() => !requestLoading && setRequestType(null)} />
          <View style={styles.modalSheet}>
            <View style={styles.sheetGrip} />
            {payment ? (
              <>
                <View style={styles.modalIcon}><MaterialIcons name="verified-user" size={22} color="#007B8B" /></View>
                <Text style={styles.modalTitle}>Validation Ligdi Cash</Text>
                <Text style={styles.modalSub}>Mode simulation : confirmez le résultat de votre paiement de {formatMoney(payment.amount)}. Votre Wallet ne changera qu'après cette confirmation serveur.</Text>
                <View style={styles.referenceCard}>
                  <Text style={styles.referenceLabel}>RÉFÉRENCE SIMULÉE</Text>
                  <Text style={styles.referenceValue}>{payment.providerReference}</Text>
                </View>
                {requestError ? <Text style={styles.requestError}>{requestError}</Text> : <Text style={styles.modalHint}>Aucun moyen de paiement réel n'est débité dans ce mode.</Text>}
                <View style={styles.modalActions}>
                  <TikisButton label="Échouer" variant="secondary" disabled={requestLoading} onPress={() => void settlePayment("failed")} style={styles.modalAction} />
                  <TikisButton label="Simuler réussite" icon="check-circle" loading={requestLoading} disabled={requestLoading} onPress={() => void settlePayment("succeeded")} style={styles.modalAction} />
                </View>
              </>
            ) : (
              <>
                <View style={styles.modalIcon}><MaterialIcons name={requestType === "deposit" ? "add-card" : "account-balance-wallet"} size={22} color="#007B8B" /></View>
                <Text style={styles.modalTitle}>{requestType === "deposit" ? "Dépôt Ligdi Cash" : "Retrait Ligdi Cash"}</Text>
                <Text style={styles.modalSub}>{requestType === "deposit" ? "Initialisez un dépôt simulé. Le solde ne sera crédité qu'après la confirmation suivante." : "Initialisez un retrait simulé. Le solde ne sera débité qu'après la confirmation suivante."}</Text>
                <View style={styles.amountWrap}>
                  <TextInput value={amountInput} onChangeText={(value) => setAmountInput(sanitizeOfferedPriceInput(value))} keyboardType="number-pad" maxLength={8} autoFocus style={styles.amountInput} placeholder="Montant" placeholderTextColor="#9AA5B6" />
                  <Text style={styles.amountCurrency}>FCFA</Text>
                </View>
                {requestError ? <Text style={styles.requestError}>{requestError}</Text> : <Text style={styles.modalHint}>Le montant et le statut de simulation seront enregistrés dans votre journal financier.</Text>}
                <View style={styles.modalActions}>
                  <TikisButton label="Annuler" variant="secondary" disabled={requestLoading} onPress={() => setRequestType(null)} style={styles.modalAction} />
                  <TikisButton label="Initialiser" loading={requestLoading} disabled={requestLoading} onPress={() => void confirmRequest()} style={styles.modalAction} />
                </View>
              </>
            )}
          </View>
        </KeyboardAvoidingView>
      </Modal>
    </SafeAreaView>
  );
}

function iconBgForTone(tone: Tone) {
  if (tone === "success") return styles.iconBgSuccess;
  if (tone === "warning") return styles.iconBgWarning;
  if (tone === "error") return styles.iconBgError;
  if (tone === "primary") return styles.iconBgPrimary;
  return styles.iconBgNeutral;
}

function QuickStat({ icon, value, label, tone }: { icon: React.ComponentProps<typeof MaterialIcons>["name"]; value: string; label: string; tone: "primary" | "success" | "amber" }) {
  return (
    <View style={styles.quickStat}>
      <View style={[styles.quickStatIcon, tone === "primary" ? styles.quickStatIconPrimary : tone === "amber" ? styles.quickStatIconAmber : styles.quickStatIconSuccess]}>
        <MaterialIcons name={icon} size={14} color={tone === "primary" ? "#007B8B" : tone === "amber" ? "#9A6200" : "#167A55"} />
      </View>
      <Text style={styles.quickStatValue}>{value}</Text>
      <Text style={styles.quickStatLabel}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  safe: { flex: 1, backgroundColor: "#EEEDF3" },

  topBar: { flexDirection: "row", alignItems: "center", paddingHorizontal: 16, paddingTop: 8, paddingBottom: 4, gap: 8 },
  iconBtn: { width: 36, height: 36, borderRadius: 10, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center", shadowColor: "#000", shadowOpacity: 0.08, shadowRadius: 3, shadowOffset: { width: 0, height: 1 }, elevation: 2 },
  topTitle: { flex: 1, color: "#111111", fontSize: 15, fontWeight: "600", textAlign: "center" },
  pressed: { opacity: 0.7 },

  scroll: { padding: 8, paddingBottom: 24, gap: 12 },

  balanceCard: { padding: 18, borderRadius: 14, gap: 10, backgroundColor: "#111111" },
  balanceCardDriver: { backgroundColor: "#111111" },
  balanceCardSender: { backgroundColor: "#007B8B" },
  balanceEyebrow: { color: "rgba(255,255,255,0.6)", fontSize: 10, fontWeight: "700", letterSpacing: 0.5, textTransform: "uppercase" },
  balanceEyebrowLight: { color: "rgba(255,255,255,0.7)" },
  balanceValueRow: { flexDirection: "row", alignItems: "flex-end", justifyContent: "space-between" },
  balanceValue: { color: "#FFFFFF", fontSize: 28, fontWeight: "700", lineHeight: 1.1 },
  trendPill: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 8, paddingVertical: 3, backgroundColor: "rgba(22,122,85,0.25)", borderRadius: 99 },
  trendText: { color: "#48B889", fontSize: 10, fontWeight: "700" },
  trendPillLight: { flexDirection: "row", alignItems: "center", gap: 3, paddingHorizontal: 8, paddingVertical: 3, backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 99 },
  trendTextLight: { color: "#FFFFFF", fontSize: 10, fontWeight: "700" },
  balanceDivider: { height: 1, backgroundColor: "rgba(255,255,255,0.12)" },
  balanceDividerLight: { backgroundColor: "rgba(255,255,255,0.18)" },
  balanceRows: { flexDirection: "row", gap: 12 },
  balanceCol: { flex: 1 },
  balanceLabel: { color: "rgba(255,255,255,0.55)", fontSize: 10, fontWeight: "600" },
  balanceLabelLight: { color: "rgba(255,255,255,0.7)" },
  balanceSub: { color: "#FFFFFF", fontSize: 12, fontWeight: "600", marginTop: 2 },
  balanceSubPending: { color: "#FBBF24" },

  actionsRow: { flexDirection: "row", gap: 8, paddingHorizontal: 8, marginTop: 6 },
  actionCard: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: 10, paddingVertical: 10, paddingHorizontal: 12, flexDirection: "row", alignItems: "center", gap: 8 },
  actionIcon: { width: 30, height: 30, borderRadius: 8, backgroundColor: "#E2F3F4", alignItems: "center", justifyContent: "center" },
  actionIconAlt: { backgroundColor: "#FEF6E2" },
  actionText: { flex: 1 },
  actionLabel: { color: "#111111", fontSize: 12, fontWeight: "600" },
  actionSub: { color: "#747474", fontSize: 9, fontWeight: "500" },

  quickStats: { flexDirection: "row", gap: 8, paddingHorizontal: 8 },
  quickStat: { flex: 1, backgroundColor: "#FFFFFF", borderRadius: 10, paddingVertical: 10, alignItems: "center", gap: 4 },
  quickStatIcon: { width: 28, height: 28, borderRadius: 8, alignItems: "center", justifyContent: "center" },
  quickStatIconPrimary: { backgroundColor: "#E2F3F4" },
  quickStatIconSuccess: { backgroundColor: "#E2F3F4" },
  quickStatIconAmber: { backgroundColor: "#FEF6E2" },
  quickStatValue: { color: "#111111", fontSize: 13, fontWeight: "700" },
  quickStatLabel: { color: "#747474", fontSize: 9, fontWeight: "600", letterSpacing: 0.4, textTransform: "uppercase" },

  senderInfo: { marginHorizontal: 8, padding: 12, backgroundColor: "#E2F3F4", borderRadius: 10, flexDirection: "row", gap: 10, alignItems: "center" },
  senderInfoIcon: { width: 32, height: 32, borderRadius: 8, backgroundColor: "#007B8B", alignItems: "center", justifyContent: "center", flexShrink: 0 },
  senderInfoText: { flex: 1, color: "#007B8B", fontSize: 11, lineHeight: 16 },
  senderInfoTextBold: { fontWeight: "700" },

  sectionHeader: { flexDirection: "row", alignItems: "center", justifyContent: "space-between", paddingHorizontal: 10, marginTop: 6 },
  sectionTitle: { color: "#747474", fontSize: 10, fontWeight: "700", letterSpacing: 0.6, textTransform: "uppercase" },
  sectionAction: { color: "#007B8B", fontSize: 11, fontWeight: "600" },

  listCard: { backgroundColor: "#FFFFFF", borderRadius: 12, overflow: "hidden" },
  txRow: { flexDirection: "row", alignItems: "center", gap: 10, paddingVertical: 12, paddingHorizontal: 12 },
  txRowDivider: { borderBottomWidth: 1, borderBottomColor: "#ECECEC" },
  txIcon: { width: 32, height: 32, borderRadius: 8, alignItems: "center", justifyContent: "center", flexShrink: 0 },
  iconBgPrimary: { backgroundColor: "#E2F3F4" },
  iconBgSuccess: { backgroundColor: "#E2F3F4" },
  iconBgWarning: { backgroundColor: "#FEF6E2" },
  iconBgError: { backgroundColor: "#FDEBEC" },
  iconBgNeutral: { backgroundColor: "#EEEDF3" },
  txBody: { flex: 1, minWidth: 0 },
  txLine1: { flexDirection: "row", alignItems: "center", gap: 6 },
  txLabel: { color: "#111111", fontSize: 12, fontWeight: "600", flex: 1 },
  txTime: { color: "#747474", fontSize: 10, flexShrink: 0 },
  txReason: { color: "#666666", fontSize: 11, marginTop: 2 },
  txAmount: { fontSize: 12, fontWeight: "700", flexShrink: 0 },
  amountCredit: { color: "#167A55" },
  amountDebit: { color: "#B4232D" },
  amountPending: { color: "#9A6200" },

  empty: { alignItems: "center", paddingVertical: 30, paddingHorizontal: 24, gap: 8 },
  emptyIcon: { width: 56, height: 56, borderRadius: 14, backgroundColor: "#FFFFFF", alignItems: "center", justifyContent: "center" },
  emptyTitle: { color: "#111111", fontSize: 14, fontWeight: "600" },
  emptySub: { color: "#666666", fontSize: 12, textAlign: "center", lineHeight: 18, maxWidth: 240 },
  emptyText: { color: "#666666", fontSize: 12, textAlign: "center", padding: 24 },

  modalOverlay: { flex: 1, justifyContent: "flex-end", backgroundColor: "rgba(0,0,0,0.42)" },
  modalSheet: { backgroundColor: "#FFFFFF", borderTopLeftRadius: 16, borderTopRightRadius: 16, padding: 16, paddingTop: 8, paddingBottom: 24 },
  sheetGrip: { width: 40, height: 4, borderRadius: 2, backgroundColor: "#D5D5DC", alignSelf: "center", marginBottom: 14 },
  modalIcon: { width: 44, height: 44, borderRadius: 9, backgroundColor: "#E2F3F4", alignSelf: "center", alignItems: "center", justifyContent: "center", marginBottom: 12 },
  modalTitle: { color: "#111111", fontSize: 17, fontWeight: "600", textAlign: "center" },
  modalSub: { color: "#666666", fontSize: 12, lineHeight: 18, textAlign: "center", marginTop: 4 },
  modalHint: { color: "#666666", fontSize: 10, lineHeight: 14, textAlign: "center", marginTop: 6 },
  referenceCard: { backgroundColor: "#EEEDF3", borderRadius: 9, padding: 12, marginTop: 14 },
  referenceLabel: { color: "#666666", fontSize: 9, fontWeight: "700", letterSpacing: 0.5, textAlign: "center" },
  referenceValue: { color: "#111111", fontSize: 12, fontWeight: "600", textAlign: "center", marginTop: 4, letterSpacing: 0.3 },
  requestError: { color: "#B4232D", fontSize: 11, fontWeight: "600", textAlign: "center", marginTop: 6 },
  amountWrap: { flexDirection: "row", alignItems: "center", backgroundColor: "#EEEDF3", borderRadius: 9, paddingHorizontal: 12, marginTop: 14 },
  amountInput: { flex: 1, color: "#111111", fontSize: 15, fontWeight: "500", minHeight: 46 },
  amountCurrency: { color: "#666666", fontSize: 11, fontWeight: "600" },
  modalActions: { flexDirection: "row", gap: 8, marginTop: 16 },
  modalAction: { flex: 1, minHeight: 42 },
});
